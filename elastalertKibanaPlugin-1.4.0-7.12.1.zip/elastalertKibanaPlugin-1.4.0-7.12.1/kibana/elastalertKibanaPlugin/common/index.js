"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'elastalertKibanaPlugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'ElastAlert';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsd0JBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRyxZQUFwQiIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBQTFVHSU5fSUQgPSAnZWxhc3RhbGVydEtpYmFuYVBsdWdpbic7XHJcbmV4cG9ydCBjb25zdCBQTFVHSU5fTkFNRSA9ICdFbGFzdEFsZXJ0JztcclxuIl19